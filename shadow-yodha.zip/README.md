# Shadow Yodha
An English action-fantasy novel written for platforms like Pocket FM and freelance publishing.

## Story Overview
Dushyant, a young man betrayed by fate, rises from the ashes of his past to become the Shadow Yodha — a mysterious warrior feared by the underworld. Each chapter unravels his journey of pain, power, and ultimate revenge.

## Chapters Included
- Chapter 1 – The Silent Betrayal
- Chapter 2 – The Name Forgotten

More chapters coming soon...

## About the Author
**Shanu Kumar**  
Scriptwriter | Digital Creator | Freelance Novelist  
📍 India  
📧 Contact: your-email@example.com  
🌐 Website: https://your-link.gumroad.com  
📸 Instagram: https://instagram.com/yourusername

---

This story is a fictional work and part of a storytelling portfolio.
